const app = getApp()
Page({



  /**
  
  * 页面的初始数据
  
  */

  data: {
    list: [],
    book: {},
    list2:[],
    list3:[],
    book3:[],
    username: ''
  },



  /**
  
  * 生命周期函数--监听页面加载
  
  */

  onShow: function () {
    this.onLoad();
  },
  onLoad: function (options) {
    var stu_name2 = options.username2;

    //获取用户的收货地址信息
    var username = wx.getStorageSync('username')
    this.setData({
      username: username
    })
    var that = this;
    wx.request({
      url: 'https://49.235.178.249/Messages1/Se1?StuNa=' + stu_name2,
      method: 'GET',
      data: {
      },
      header: {
        'content-type': 'application/json'
      },
      success: function (res) {
        console.log(res.data);
        that.setData({
          list3: res.data,
          book3: res.data[0]
        })
      }
    })




    var that = this;
    var stu_name=options.username;
    var stu_name2 = options.username2;
    var book_name = options.bk;
    var book_autor = options.at;
    var book_press = options.cb;
    var book_price = options.rmb;
    var book_type = options.z;
    var book_message = options.xx;
    var book_ifsale=options.ty
    var book_number = options.num
    console.log(options);
    that.setData({
      book: { stu_name, stu_name2, book_name, book_type, book_autor, book_press, book_price, book_message,book_ifsale,book_number}
    })
    //返回收藏列表
    var that = this;
    var StuNa = wx.getStorageSync('username')
    that.setData({
      StuNa: StuNa
    })
    wx.request({
      url: 'https://49.235.178.249/History/collect?StuName=' + StuNa,
      method: 'GET',
      data: {
      },
      header: {
        'content-type': 'application/json'
      },
      success: function (res) {
        console.log(res.data);
        that.setData({
          list2: res.data
        })
      }
    })
    

  },
  love: function () {
    var that = this;
    var booknum = this.data.book.book_number
    var StuNa = wx.getStorageSync('username')
    that.setData({
      StuNa: StuNa
    })
    wx.request({
      url: 'https://49.235.178.249/Collect/book?Collectbooknum=' + booknum + '&Collectbookname=' + StuNa,
      method: 'GET',
      data: {
      },
      header: {
        'content-type': 'application/json'
      },
      success: function (res) {
        wx.showToast({
          title: '收藏成功！',
          icon: 'success',
          duration: 1500
        })
      }
    })
  },
  quxiao: function () {
    var that = this;
    var booknum = this.data.book.book_number
    var StuNa = wx.getStorageSync('username')
    that.setData({
      StuNa: StuNa
    })
    wx.showModal({
      title: '提示',
      content: '确定取消收藏该书籍吗？',
      success: function (res) {
        if (res.confirm) {
          wx.request({
            url: 'https://49.235.178.249/Delectcollect/book?Collectbooknum=' + booknum + '&Collectbookname=' + StuNa,
            method: 'GET',
            data: {
            },
            header: {
              'content-type': 'application/json'
            },
            success: function (res) {
              wx.showToast({
                title: '已取消收藏！',
                icon: 'success',
                duration: 1500
              })
            }
          })
        }
        else {//这里是点击了取消以后

        }
      }
    })
  },
  yes: function () {
    var number = this.data.book.book_number
    var type = this.data.book.book_ifsale
    var fbname = this.data.book.stu_name
    var that = this
    var StuNa = wx.getStorageSync('username')
    that.setData({
      StuNa: StuNa
    })
    if (type == '出售中' & fbname != StuNa) {
      wx.showModal({
        title: '提示',
        content: '确定购买该书籍吗？',
        success: function (res) {

          if (res.confirm) {//这里是点击了确定以后
            wx.request({
              url: 'https://49.235.178.249/Buy/Book?booknumber=' + number + '&bookStuNa2=' + StuNa,
              method: 'GET',
              data: {
              },
              header: {
                'content-type': 'application/json'
              },
              success: function (res) {
                console.log(res.data);
              }
            })

            wx.showToast({
              title: '购买成功！',
              icon: 'success',
              duration: 1500
            })
            setTimeout(function () {
              wx.navigateBack({
                delta: 1
              })
            }, 1500)
          } else {//这里是点击了取消以后

          }
        }
      })
    }
    if (type == '已出售' & fbname != StuNa) {
      wx.showModal({
        title: '提示',
        content: '该商品已经出售。按确定返回上一步，按取消继续查看该商品信息！（如急需该商品可前往发布求购信息！）',
        success: function (res) {

          if (res.confirm) {//这里是点击了确定以后
            wx.navigateBack({
              delta: 1
            })
          } else {//这里是点击了取消以后

          }
        }
      })
    }
    if (type == '出售中' & fbname == StuNa) {
      wx.showModal({
        title: '提示',
        content: '该商品正在出售中，您不可购买自己发布的商品!',
        success: function (res) {

          if (res.confirm) {//这里是点击了确定以后
            wx.navigateBack({
              delta: 1
            })
          } else {//这里是点击了取消以后

          }
        }
      })
    }
    if (type == '已出售' & fbname == StuNa) {
      wx.showModal({
        title: '提示',
        content: '您的商品已被购买，是否前往 ‘我的’ -> ‘交易记录’ 查看？',
        success: function (res) {

          if (res.confirm) {//这里是点击了确定以后
             wx.navigateTo({
              url: '../Record/Record'
            })
          } else {//这里是点击了取消以后

          }
        }
      })
    }
    if (type == '求购中' & fbname == StuNa) {
      wx.showModal({
        title: '提示',
        content: '您的商品还无人关顾喔！',
        success: function (res) {

          if (res.confirm) {//这里是点击了确定以后
            wx.navigateBack({
              delta: 1
            })
          } else {//这里是点击了取消以后

          }
        }
      })
    }
    if (type == '已求购' & fbname == StuNa) {
      wx.showModal({
        title: '提示',
        content: '您发布的商品已经被回应，是否前往‘我的’->‘交易记录’查看？',
        success: function (res) {

          if (res.confirm) {//这里是点击了确定以后
            wx.navigateTo({
              url: '../Record/Record'
            })
          } else {//这里是点击了取消以后

          }
        }
      })
    }
    if (type == '求购中' & fbname != StuNa) {
      wx.showModal({
        title: '提示',
        content: '您确定提供该商品给发布者吗？',
        success: function (res) {

          if (res.confirm) {//这里是点击了确定以后
            wx.request({
              url: 'https://49.235.178.249/Buy/Book?booknumber=' + number + '&bookStuNa2=' + StuNa,
              method: 'GET',
              data: {
              },
              header: {
                'content-type': 'application/json'
              },
              success: function (res) {
                console.log(res.data);
              }
            })

            wx.showToast({
              title: '出售成功！',
              icon: 'success',
              duration: 1500
            })
            setTimeout(function () {
              wx.navigateBack({
                delta: 1
              })
            }, 1500)
          } else {//这里是点击了取消以后

          }
        }
      })
    }
    if (type == '已求购' & fbname != StuNa) {
      wx.showModal({
        title: '提示',
        content: '该商品已经有卖家提供，如有资源可以前往发布！',
        success: function (res) {

          if (res.confirm) {//这里是点击了确定以后
            wx.navigateTo({
              url: '../sell/sell'
            })
          } else {//这里是点击了取消以后

          }
        }
      })
    }
  },


  /**
  
  * 生命周期函数--监听页面初次渲染完成
  
  */

  onReady: function () {
// 修改导航栏标题
    wx.setNavigationBarTitle({
      title: '交易信息详情'
    })
  },



  /**
  
  * 生命周期函数--监听页面显示
  
  */

  onShow: function () {

  },



  /**
  
  * 生命周期函数--监听页面隐藏
  
  */

  onHide: function () {

  },



  /**
  
  * 生命周期函数--监听页面卸载
  
  */

  onUnload: function () {

  },



  /**
  
  * 页面相关事件处理函数--监听用户下拉动作
  
  */

  onPullDownRefresh: function () {

  },



  /**
  
  * 页面上拉触底事件的处理函数
  
  */

  onReachBottom: function () {

  },



  /**
  
  * 用户点击右上角分享
  
  */

  onShareAppMessage: function () {

  }

})