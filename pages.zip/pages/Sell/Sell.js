const app = getApp()
Page({



  /**
  
  * 页面的初始数据
  
  */

  data: {
    username: '',
    getinput: null,
    getinput2: null,
    getinput3: null,
    getinput4: null,
    getinput5: null,
    tipHide: false,
    chooseTypeHide: true

  },
  getinput: function (e) {//方法1
    this.data.getinput = e.detail.value;
  },
  getinput2: function (e) {//方法2
    this.data.getinput2 = e.detail.value;
  },
  getinput3: function (e) {//方法3
    this.data.getinput3 = e.detail.value;
  },
  getinput4: function (e) {//方法4
    this.data.getinput4 = e.detail.value;
  },
  getinput5: function (e) {//方法5
    this.data.getinput5 = e.detail.value;
  },

  yes: function () {
   if (this.data.getinput4 == null)
      wx.showModal({
        title: '价格不能为空！',
        icon: 'false',
        duration: 2000
      })
    if (this.data.getinput3 == null)
      wx.showModal({
        title: '出版社不能为空！',
        icon: 'false',
        duration: 2000
      }) 
    if (this.data.getinput2 == null)
      wx.showModal({
        title: '作者不能为空！',
        icon: 'false',
        duration: 2000
      }) 
    if (this.data.getinput == null)
      wx.showModal({
        title: '书籍名称不能为空！',
        icon: 'false',
        duration: 2000,
      })
    if (this.data.getinput5 == null)
      this.data.getinput5 = '无'
    if (this.data.getinput != null && this.data.getinput2 != null && this.data.getinput3 != null && this.data.getinput4 != null && this.data.getinput5 != null){

      wx.showLoading({
        title: '发布上传中...',
        duration: 4000
      
      })
    wx.request({
      url: 'https://49.235.178.249/hello/book',
      method: 'GET',
      data: {
        StuName:this.data.username,
        name: this.data.getinput,
        autor: this.data.getinput2,
        press: this.data.getinput3,
        price: this.data.getinput4,
        Message: this.data.getinput5,
        type: "出售",
        bookifsale:"出售中"
      },
      header: {
        'content-type': 'application/json'
      },
      success: function (res) {
        console.log(res.data);
        wx.hideLoading()
        wx.showToast({
          title: '发布成功！',
          icon: 'success',
          duration: 1500
        })
        setTimeout(function () {
          wx.navigateBack({
            delta: 1
          })
        }, 1500)
      },
      
    })
  }
  },
  no: function () {
    wx.showModal({
      title: '提示',
      content: '确定退出信息录入吗',
      success: function (res) {
        if (res.confirm) {//这里是点击了确定以后
          wx.navigateBack({
            delta:1
          })
        } else {//这里是点击了取消以后
          
        }
      }
    })
  },
  
  chooseImg: function () {
    let that = this
    wx.chooseImage({
      count: 1, // 默认9
      sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
      sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
      success: function (res) {
        console.log(res)
        var tempFilePaths = res.tempFilePaths
        that.data.images = tempFilePaths
        // 多图片
        // that.data.urls = that.data.urls.concat(tempFilePaths)
        // 单图片
        that.data.urls = tempFilePaths[0]
        that.setData({
          images: tempFilePaths[0],
          urls: that.data.urls
        })

      }
    })
  },

  /**
  
  * 生命周期函数--监听页面加载
  
  */

  onLoad: function (options) {
    var username = wx.getStorageSync('username')
    this.setData({
      username: username
    })
  },



  /**
  
  * 生命周期函数--监听页面初次渲染完成
  
  */

  onReady: function () {

  },



  /**
  
  * 生命周期函数--监听页面显示
  
  */

  onShow: function () {

  },



  /**
  
  * 生命周期函数--监听页面隐藏
  
  */

  onHide: function () {

  },



  /**
  
  * 生命周期函数--监听页面卸载
  
  */

  onUnload: function () {

  },



  /**
  
  * 页面相关事件处理函数--监听用户下拉动作
  
  */

  onPullDownRefresh: function () {

  },



  /**
  
  * 页面上拉触底事件的处理函数
  
  */

  onReachBottom: function () {

  },



  /**
  
  * 用户点击右上角分享
  
  */

  onShareAppMessage: function () {

  }

})