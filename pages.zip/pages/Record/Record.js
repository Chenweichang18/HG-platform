var app = getApp()
Page({
  data: {
    winWidth: 0,
    winHeight: 0,
    // tab切换  
    currentTab: 0,
    list: [],
    list2:[],
    list3:[],
    username: ''
  },
  onLoad: function () {
    var that = this;
    var StuNa = wx.getStorageSync('username')
    that.setData({
      StuNa: StuNa
    })

    /*全部交易记录（已完成）*/
    wx.request({
      url: 'https://49.235.178.249/Transaction/T?StuNa=' + StuNa,
      method: 'GET',
      data: {
      },
      header: {
        'content-type': 'application/json'
      },
      success: function (res) {
        console.log(res.data);
        that.setData({
          list: res.data
        })
      }
    })

    /*出售交易记录（已完成）*/
    wx.request({
      url: 'https://49.235.178.249/SALED/Transaction?StuNa=' + StuNa,
      method: 'GET',
      data: {
      },
      header: {
        'content-type': 'application/json'
      },
      success: function (res) {
        console.log(res.data);
        that.setData({
          list2: res.data
        })
      }
    })

    /*求购交易记录（已完成）*/
    wx.request({
      url: 'https://49.235.178.249/BUYED/Transaction?StuNa=' + StuNa,
      method: 'GET',
      data: {
      },
      header: {
        'content-type': 'application/json'
      },
      success: function (res) {
        console.log(res.data);
        that.setData({
          list3: res.data
        })
      }
    })


    /** 
     * 获取系统信息 
     */
    wx.getSystemInfo({

      success: function (res) {
        that.setData({
          winWidth: res.windowWidth,
          winHeight: res.windowHeight
        });
      }

    });
  },
  onReady: function () {
    // 修改导航栏标题
    wx.setNavigationBarTitle({
      title: '交易记录'
    })
  },

  /** 
     * 滑动切换tab 
     */
  bindChange: function (e) {

    var that = this;
    that.setData({ currentTab: e.detail.current });

  },
  /** 
   * 点击tab切换 
   */
  swichNav: function (e) {

    var that = this;

    if (this.data.currentTab === e.target.dataset.current) {
      return false;
    } else {
      that.setData({
        currentTab: e.target.dataset.current
      })
    }
  }
})  