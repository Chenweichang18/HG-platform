//index.js
//获取应用实例
const app = getApp()

Page({
  data: {
    list:[],
    inputValue: '', //搜索的内容
  },
  
  onPullDownRefresh: function () {

    wx.showNavigationBarLoading() //在标题栏中显示加载

    //模拟加载

    setTimeout(function () {

      // complete

      wx.hideNavigationBarLoading() //完成停止加载

      wx.stopPullDownRefresh() //停止下拉刷新

    }, 1500);
    wx.showToast({
      title: '玩命加载中',
      "icon": "loading",
      "duration": 1500
    })
    this.onLoad();
    
  },
  inputBind:function(e){
    this.setData({
    inputValue:e.detail.value
    })
  },
  query: function (e) {
    wx.navigateTo({
      url: '/pages/search/search?Search=' + this.data.inputValue
    })
  },
  //事件处理函数
  bindViewTap: function() {
    wx.navigateTo({
      url: '../logs/logs'
    })
  },
  onShow: function () {
    wx.showToast({
      title: '玩命加载中',
      "icon": "loading",
      "duration": 1500
    })
    this.onLoad();
  },
  onLoad: function () {
    var that=this;
    wx.request({
      url: 'https://49.235.178.249/jdbc/booklist',
      method: 'GET',
      data: {
      },
      header: {
        'content-type': 'application/json'
      },
      success: function (res) {
        console.log(res.data);
        that.setData({
          list:res.data
        })
      }
    })







    if (app.globalData.userInfo) {
      this.setData({
        userInfo: app.globalData.userInfo,
        hasUserInfo: true
      })
    } else if (this.data.canIUse){
      // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
      // 所以此处加入 callback 以防止这种情况
      app.userInfoReadyCallback = res => {
        this.setData({
          userInfo: res.userInfo,
          hasUserInfo: true
        })
      }
    } else {
      // 在没有 open-type=getUserInfo 版本的兼容处理
      wx.getUserInfo({
        success: res => {
          app.globalData.userInfo = res.userInfo
          this.setData({
            userInfo: res.userInfo,
            hasUserInfo: true
          })
        }
      })
    }
  },
  getUserInfo: function(e) {
    console.log(e)
    app.globalData.userInfo = e.detail.userInfo
    this.setData({
      userInfo: e.detail.userInfo,
      hasUserInfo: true
    })
  },
   onShareAppMessage: function (res) {
    var that = this;
    return {
      title: '',
      path: 'pages/list/list?id=' + that.data.scratchId,
      success: function (res) {
        // 转发成功
        that.shareClick();
      },
      fail: function (res) {
        // 转发失败
      }
    }
  },
})
